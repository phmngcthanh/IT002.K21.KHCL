#include "DaGiac.cpp"

int main(){
    DaGiac a;
    a.Nhap();
    a.Xuat();
    a.Dichuyen(5);
    a.Xuat();
    a.Zoom(3);
    a.Xuat();
    a.Quay(3.14 / 6);
    a.Xuat();
}


