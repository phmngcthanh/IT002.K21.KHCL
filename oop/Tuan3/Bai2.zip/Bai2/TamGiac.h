#include "Diem.cpp"

class TamGiac {

    private:
        Diem m, n, p;
    public:
        void Nhap();
        void Xuat();
        TamGiac();
        TamGiac(const TamGiac&);
        TamGiac(Diem, Diem, Diem);
        ~TamGiac();
        void Dichuyen(const double&);
        void Quay(const double&);
        void Zoom(const double&);

};