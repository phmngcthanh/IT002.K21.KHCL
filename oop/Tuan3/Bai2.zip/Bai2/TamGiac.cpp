#include "TamGiac.h"

void TamGiac::Nhap() {
    m.Nhap();
    n.Nhap();
    p.Nhap();
}

void TamGiac::Xuat() {
    m.Xuat();
    n.Xuat();
    p.Xuat();
}

void TamGiac::Dichuyen(const double& t) {
    m.Movexy(t);
    n.Movexy(t);
    p.Movexy(t);
}

void TamGiac::Quay(const double& rad) {
    m.Quay(rad);
    n.Quay(rad);
    p.Quay(rad);
}

void TamGiac::Zoom(const double& k) {
    m.Zoom(k);
    n.Zoom(k);
    p.Zoom(k);
}

TamGiac::TamGiac() {
}

TamGiac::TamGiac(const TamGiac& x) {
    m = x.m;
    n = x.n;
    p = x.p;

}
TamGiac::TamGiac(Diem x, Diem y, Diem z) {
    m = x;
    n = y;
    p = z;
}
TamGiac::~TamGiac() {}

