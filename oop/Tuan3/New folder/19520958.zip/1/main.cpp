
#include "Point.cpp"
int main()
{
    Point a,b;
    cin>>a;
    cin>>b;
    cout<<a;
    cout<<b;
}