#include "TamGiac.cpp"

int main() {

    TamGiac a;
    cin>>a;
    cout<<a;
    return 0;
}
