#include "Time.cpp"

int main() {
Time a,b,c;
cin>>a>>b;
//3
// 4
c=a+b;
cout<<"a+b= "<< c;

c=a-b;
    cout<<"a-b= "<< c;
a++;

cout<<"a++= "<<a;
b--;
cout<<"b--= "<<a;
return 0;
}
