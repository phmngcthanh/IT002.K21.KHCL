#include  "DaGiac.cpp"
int main() {
    DaGiac a;
    cin>>a;
    cout<<a;
    return 0;
}
