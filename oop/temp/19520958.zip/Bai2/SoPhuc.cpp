//
// Created by ThanhPN on 4/16/2020.
//
#include "SoPhuc.h"
#include <cmath>
void SoPhuc::Xuat()
{
 std::cout<<Thuc<<"+"<<Ao<<"i"<<std::endl;
}
void SoPhuc::Nhap()
{
    float x,y;
    std::cin>>x;
    std::cin>>y;
    Thuc=x;
    Ao=y;
}
float SoPhuc::Abs()
{
    return (sqrt((Thuc * Thuc) + (Ao * Ao))) ;
}

SoPhuc SoPhuc::Cong(SoPhuc a)
{
    SoPhuc b;
    b.Thuc= Thuc+a.Thuc;
    b.Ao= Ao+a.Ao;
    return b;
};

SoPhuc SoPhuc::Tru(SoPhuc a)
{
    SoPhuc b;
    b.Thuc= Thuc-a.Thuc;
    b.Ao= Ao-a.Ao;
    return b;
};

SoPhuc SoPhuc::Nhan(SoPhuc a)
{
    SoPhuc b;
    b.Thuc=Thuc*a.Thuc-Ao*a.Ao;
    b.Ao=Thuc*a.Ao+Ao*a.Thuc;
    return b;
};
SoPhuc SoPhuc::Chia(SoPhuc a)
{
    SoPhuc  b;
    b.Thuc=(Thuc*a.Thuc+Ao*a.Ao)/(a.Thuc*a.Thuc+a.Ao*a.Ao);
    b.Ao=(a.Thuc*Ao-Thuc*a.Ao)/(a.Thuc*a.Thuc+a.Ao*a.Ao);
    return b;
};