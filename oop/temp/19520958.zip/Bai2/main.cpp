#include <iostream>
#include "SoPhuc.cpp"
int main() {
    SoPhuc a,b,c;
    a.Nhap();
    b.Nhap();
    c= a.Cong(b);
    c.Xuat();
    c= a.Tru(b);
    c.Xuat();
    c= a.Nhan(b);
    c.Xuat();
    c= a.Chia(b);
    c.Xuat();
    return 0;
}
