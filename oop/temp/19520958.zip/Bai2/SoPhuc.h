//
// Created by ThanhPN on 4/16/2020.
//

#ifndef LLL_SOPHUC_H
#define LLL_SOPHUC_H
class SoPhuc
{
private:
    float Thuc;
    float Ao;
public:
    void Xuat();
    void Nhap();
    float Abs();
    SoPhuc Cong(SoPhuc);
    SoPhuc Tru(SoPhuc);
    SoPhuc Nhan(SoPhuc);
    SoPhuc Chia(SoPhuc);
};


#endif //LLL_SOPHUC_H
